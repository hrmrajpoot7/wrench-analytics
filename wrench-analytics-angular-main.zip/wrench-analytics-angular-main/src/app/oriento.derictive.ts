import { Directive, HostBinding, HostListener, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[orientatio]'
})
export class OrientatioDirective implements OnInit {
  @HostBinding('class') state;

  ngOnInit() {
    this.updateOrientatioState();
  }
  showError() {
    this.toastr.warning('View Warning', 'For Best experience view in LANDSCAPE MODE!!!', {
      timeOut: 6000
    });
  }
  constructor(private toastr: ToastrService) {}
  @HostListener('window:resize') updateOrientatioState() {
    if (window.innerHeight > window.innerWidth) {
      this.showError();
    } else {
      console.log('In landscape :) ');
    }
  }
}
