import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [
  {
    label: 'Main',
    isTitle: true
  },
  {
    label: 'Dashboard',
    link: '/dashboard',
    icon: 'home'
  },
  {
    label: 'Analytical Reports',
    isTitle: true
  },
  {
    label: 'List',
    subItems: [
      {
        label: 'Customer Credit',
        link: '/apps/report/customer'
      },
      {
        label: 'Vendor Performance',
        link: '/apps/report/vendor'
      },
      {
        label: 'Production Dashboard',
        link: '/apps/report/production'
      },
      {
        label: 'Sales Report',
        link: '/apps/report/sales'
      },
      {
        label: 'Part Lead Time',
        link: '/apps/report/partTime'
      },
      {
        label: 'Forecasting',
        link: '/apps/report/demandPlanning'
      },
      {
        label: 'Demand Planning',
        link: '/apps/report/demandPlanningWithPython'
      },
      {
        label: 'Customer Buying Patterns',
        link: '/apps/report/predictionByCustomerBuyingPatterns'
      },
      {
        label: 'Trend By Metal Prices',
        link: '/apps/report/trendByMetalPrice'
      },
      {
        label: 'Sales Pipeline Report',
        link: '/apps/report/salesPipelineReport'
      }
    ]
  }
];
