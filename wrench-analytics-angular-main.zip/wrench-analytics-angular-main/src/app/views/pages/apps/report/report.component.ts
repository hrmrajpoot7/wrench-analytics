import { Component, NgZone, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { numberAndReportMapper } from '../../../../../environments/mapper';
import * as pbi from 'powerbi-client';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit, OnChanges {
  public isAsideNavCollapsed = true;
  urlParam = '';
  reportTitle: string;
  report: pbi.Embed;
  loading = false;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private zone: NgZone
  ) {}
  ngOnChanges(changes: SimpleChanges): void {
    console.log('changes', changes);
  }

  ngOnInit(): void {
    const urlArray = this.router.url.split('/');
    this.urlParam = urlArray[urlArray.length - 1];
    this.reportTitle = numberAndReportMapper[this.urlParam].title;
  }
}
