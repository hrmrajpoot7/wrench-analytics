import {
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { Location } from '@angular/common';
import { numberAndReportMapper } from '../../../../../../environments/mapper';
import { HttpClient } from '@angular/common/http';
import { models } from 'powerbi-client';
import * as pbi from 'powerbi-client';
import { environment } from '../../../../../../environments/environment';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter, map, mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-read',
  templateUrl: './read.component.html',
  styleUrls: ['./read.component.scss']
})
export class ReadComponent implements OnInit {
  @Input() urlParam: string;
  constructor(private httpClient: HttpClient) {}

  reportTitle: string;
  report: pbi.Embed;
  loading = false;
  @ViewChild('reportContainer_1', { static: false }) reportContainer: ElementRef;

  async makeCallToServiceFromReport(reportType) {
    this.loading = true;
    const apiUrl = environment.EMBED_GENERATION_LINK;
    const promiseCall = this.httpClient.get(`${apiUrl}/${reportType}`).toPromise();
    const result = await promiseCall;
    this.showReport(result);
  }
  showReport(result: any) {
    const settings: pbi.IEmbedSettings = {
      panes: {
        filters: {
          expanded: false,
          visible: false
        }
      },
      background: models.BackgroundType.Transparent,
      layoutType: models.LayoutType.Custom,
      customLayout: {
        displayOption: models.DisplayOption.FitToPage
      }
    };
    const config: pbi.IEmbedConfiguration = {
      type: 'report',
      tokenType: pbi.models.TokenType.Embed,
      accessToken: result.accessToken,
      embedUrl: result.embedUrl,
      id: result.embedReportId,
      filters: [],
      settings
    };
    const reportContainer = this.reportContainer.nativeElement;
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory
    );
    powerbi.reset(reportContainer);
    this.report = powerbi.embed(reportContainer, config);
    this.report.off('loaded');
    this.report.on('loaded', () => {
      console.log('Loaded');
      this.loading = false;
    });
    this.report.on('error', () => {
      console.log('Error');
    });
  }
  ngOnInit(): void {
    this.makeCallToServiceFromReport(this.urlParam);
  }
}
