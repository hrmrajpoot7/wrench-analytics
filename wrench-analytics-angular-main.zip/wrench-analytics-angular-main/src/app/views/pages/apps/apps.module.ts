import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { FullCalendarModule } from '@fullcalendar/angular'; // for FullCalendar!
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interactionPlugin from '@fullcalendar/interaction';

import {
  NgbDropdownModule,
  NgbTooltipModule,
  NgbNavModule,
  NgbCollapseModule
} from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { SimplemdeModule, SIMPLEMDE_CONFIG } from 'ng2-simplemde';

import { AppsComponent } from './apps.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { HttpClientModule } from '@angular/common/http';
import { ReportComponent } from './report/report.component';
import { ReadComponent } from './report/read/read.component';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

FullCalendarModule.registerPlugins([
  dayGridPlugin,
  timeGridPlugin,
  listPlugin,
  interactionPlugin
]);

const routes: Routes = [
  {
    path: '',
    component: AppsComponent,
    children: [
      {
        path: 'report',
        children: [
          {
            path: '',
            redirectTo: 'customer',
            pathMatch: 'full'
          },
          {
            path: 'customer',
            component: ReportComponent,
            data: {
              urlParam: 'customer'
            }
          },
          {
            path: 'vendor',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'vendor'
            }
          },
          {
            path: 'production',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'production'
            }
          },
          {
            path: 'sales',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'sales'
            }
          },
          {
            path: 'partTime',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'partTime'
            }
          },
          {
            path: 'demandPlanning',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'demandPlanning'
            }
          },
          {
            path: 'demandPlanningWithPython',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'demandPlanningWithPython'
            }
          },
          {
            path: 'predictionByCustomerBuyingPatterns',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'predictionByCustomerBuyingPatterns'
            }
          },
          {
            path: 'trendByMetalPrice',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'trendByMetalPrice'
            }
          },
          {
            path: 'salesPipelineReport',
            pathMatch: 'full',
            component: ReportComponent,
            data: {
              urlParam: 'salesPipelineReport'
            }
          }
        ]
      }
    ]
  }
];

@NgModule({
  declarations: [ReportComponent, AppsComponent, ReadComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule,
    RouterModule.forChild(routes),
    FormsModule,
    FullCalendarModule, // import the FullCalendar module! will make the FullCalendar component available
    PerfectScrollbarModule,
    NgbDropdownModule,
    NgbTooltipModule,
    NgbNavModule,
    NgbCollapseModule,
    NgSelectModule,
    SimplemdeModule.forRoot({
      provide: SIMPLEMDE_CONFIG,
      useValue: {}
    })
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class AppsModule {}
