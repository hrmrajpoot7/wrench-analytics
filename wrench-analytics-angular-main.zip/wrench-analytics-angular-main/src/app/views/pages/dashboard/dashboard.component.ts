import {
  Component,
  ElementRef,
  OnChanges,
  OnInit,
  SimpleChange,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import * as pbi from 'powerbi-client';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { models, Embed } from 'powerbi-client';
import { numberAndReportMapper } from '../../../../environments/mapper';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  preserveWhitespaces: true
})
export class DashboardComponent implements OnInit, OnChanges {
  report: pbi.Embed;
  reportTitle = '';
  @ViewChild('reportContainer', { static: false }) reportContainer: ElementRef;
  constructor(private httpClient: HttpClient) {}
  async makeCallToService(reportType) {
    this.reportTitle = numberAndReportMapper[reportType].title;
    console.log(this.reportTitle, 'this.reportTitle');
    const apiUrl = environment.EMBED_GENERATION_LINK;
    console.log(`${apiUrl}/${reportType}`);
    const promiseCall = this.httpClient.get(`${apiUrl}/${reportType}`).toPromise();
    const result = await promiseCall;
    console.log('result', result);
    this.showReport(result);
  }
  showReport(result: any) {
    const settings: pbi.IEmbedSettings = {
      panes: {
        filters: {
          expanded: false,
          visible: true
        }
      },
      background: models.BackgroundType.Transparent,
      layoutType: models.LayoutType.Custom,
      customLayout: {
        displayOption: models.DisplayOption.FitToPage
      }
    };
    const config: pbi.IEmbedConfiguration = {
      type: 'report',
      tokenType: pbi.models.TokenType.Embed,
      accessToken: result.accessToken,
      embedUrl: result.embedUrl,
      id: result.embedReportId,
      filters: [],
      settings
    };
    const reportContainer = this.reportContainer.nativeElement;
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory
    );
    powerbi.reset(reportContainer);
    this.report = powerbi.embed(reportContainer, config);
    this.report.off('loaded');
    this.report.on('loaded', () => {
      console.log('Loaded');
    });
    this.report.on('error', () => {
      console.log('Error');
    });
  }
  ngOnInit(): void {
    if (this.reportTitle === '') this.makeCallToService('customer');
  }
  ngOnChanges(change: SimpleChanges): void {
    console.log(change);
  }
}
