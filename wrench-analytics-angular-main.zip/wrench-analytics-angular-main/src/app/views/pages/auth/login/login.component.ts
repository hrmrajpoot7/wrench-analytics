import { Component, isDevMode, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../../../environments/environment';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  returnUrl: any;
  error: string;
  showErrorAlert: true;
  loginForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl('')
  });
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
  }

  showFailure(error: string) {
    this.toastr.error('Could not Login', error, {
      timeOut: 3000
    });
  }
  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      console.error('An error occurred:', error.error);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` + `body was: ${error.error}`
      );
    }
    return 'Something bad happened; please try again later.';
  }
  checkCredentials(url: string, credentials: Record<string, any>): Promise<any> {
    return this.http
      .put<any>(url, credentials)
      .pipe(catchError(this.handleError))
      .toPromise();
  }
  async login(e) {
    e.preventDefault();
    try {
      const { email, password } = this.loginForm.value;

      const credentials = {
        email,
        password,
        loginTimestamp: new Date().toString(),
        appName: 'Wrench-Analytics'
      };
      const loginUrl = environment.APP_LOGIN_URL;
      const data = await this.checkCredentials(loginUrl, credentials);

      if (data.comparison) {
        console.log('setting is loggedIn to true');
        localStorage.setItem('isLoggedin', 'true');
        localStorage.setItem('user', email);
      } else {
        console.log('setting is loggedIn to false');
        localStorage.setItem('isLoggedin', 'false');
        console.log(data);
        this.showFailure(data.message);
      }
      this.onLoggedin();
    } catch (error) {}
  }
  onLoggedin() {
    console.log('localStorage', localStorage.getItem('isLoggedin'));
    if (localStorage.getItem('isLoggedin') === 'true') {
      this.router.navigate([this.returnUrl]);
    }
  }
}
