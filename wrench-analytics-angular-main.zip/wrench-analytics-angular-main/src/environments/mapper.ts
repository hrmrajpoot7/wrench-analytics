export const numberAndReportMapper = {
  customer: {
    title: 'Customer Credit',
    imgPath: '/1.jpeg',
    cName: 'nav-text',
    urlParam: 'customer'
  },
  vendor: {
    title: 'Vendor Performance',
    imgPath: '/2.jpeg',
    cName: 'nav-text',
    urlParam: 'vendor'
  },
  production: {
    title: 'Production Dashboard',
    imgPath: '/3.jpg',
    cName: 'nav-text',
    urlParam: 'production'
  },
  sales: {
    title: 'Sales Report',
    imgPath: '/4.jpeg',
    cName: 'nav-text',
    urlParam: 'sales'
  },
  partTime: {
    title: 'Part Lead Time ',
    imgPath: '/5.png',
    cName: 'nav-text',
    urlParam: 'partTime'
  },
  demandPlanning: {
    title: 'Forecasting and Demand Planning ',
    imgPath: '/6.png',
    cName: 'nav-text',
    urlParam: 'demandPlanning'
  },
  demandPlanningWithPython: {
    title: 'Forecasting and Demand Planning with Python',
    imgPath: '/7.png',
    cName: 'nav-text',
    urlParam: 'demandPlanningWithPython'
  },
  predictionByCustomerBuyingPatterns: {
    title: 'Prediction By Customer Buying Patterns',
    imgPath: '/8.png',
    cName: 'nav-text',
    urlParam: 'predictionByCustomerBuyingPatterns'
  },
  trendByMetalPrice: {
    title: 'Trend By Metal Prices',
    imgPath: '/9.png',
    cName: 'nav-text',
    urlParam: 'trendByMetalPrice'
  },
  salesPipelineReport: {
    title: 'Sales Pipeline Report',
    imgPath: '/10.png',
    cName: 'nav-text',
    urlParam: 'salesPipelineReport'
  }
};
