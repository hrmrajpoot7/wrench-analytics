export const environment = {
  production: true,
  APP_LOGIN_URL: 'http://54.83.133.239:8080/ratchet/api/customers/login',
  EMBED_GENERATION_LINK: 'http://54.83.133.239:5300/embedTokenGeneration/getEmbedToken'
};
